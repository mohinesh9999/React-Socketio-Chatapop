import React from 'react';
import Messenger from '../Messenger';

export default function App() {
    return (
      <div className="App">
        <Messenger />
      </div>
    );
}